package com.raylan.moduleai

import android.content.pm.PackageManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

class ShizukuExecutor {

  private val _status = MutableStateFlow(ShizukuStatus())
  val status: StateFlow<ShizukuStatus> = _status.asStateFlow()

  private var listenersRegistered = false

  private val binderReceivedListener = Shizuku.OnBinderReceivedListener { refreshStatus() }
  private val binderDeadListener = Shizuku.OnBinderDeadListener { refreshStatus() }
  private val permissionResultListener =
    Shizuku.OnRequestPermissionResultListener { _, grantResult ->
      refreshStatus(explicitGranted = grantResult == PackageManager.PERMISSION_GRANTED)
    }

  fun registerListeners() {
    if (listenersRegistered) {
      refreshStatus()
      return
    }
    runCatching {
      Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
      Shizuku.addBinderDeadListener(binderDeadListener)
      Shizuku.addRequestPermissionResultListener(permissionResultListener)
      listenersRegistered = true
    }
    refreshStatus()
  }

  fun unregisterListeners() {
    if (!listenersRegistered) return
    runCatching {
      Shizuku.removeBinderReceivedListener(binderReceivedListener)
      Shizuku.removeBinderDeadListener(binderDeadListener)
      Shizuku.removeRequestPermissionResultListener(permissionResultListener)
      listenersRegistered = false
    }
  }

  fun refreshStatus(explicitGranted: Boolean? = null) {
    val updated =
      runCatching {
          val alive = Shizuku.pingBinder()
          if (!alive) {
            ShizukuStatus(
              state = ShizukuConnectionState.DISCONNECTED,
              uid = -1,
              binderAlive = false,
            )
          } else {
            val isGranted =
              explicitGranted
                ?: (runCatching { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED }
                  .getOrDefault(false))
            val uid = runCatching { Shizuku.getUid() }.getOrDefault(-1)
            ShizukuStatus(
              state =
                if (isGranted) {
                  ShizukuConnectionState.CONNECTED_GRANTED
                } else {
                  ShizukuConnectionState.CONNECTED_NO_PERMISSION
                },
              uid = uid,
              binderAlive = true,
            )
          }
        }
        .getOrElse {
          ShizukuStatus(
            state = ShizukuConnectionState.DISCONNECTED,
            uid = -1,
            binderAlive = false,
          )
        }
    _status.value = updated
  }

  fun requestPermission(): Result<Unit> {
    return runCatching {
      refreshStatus()
      if (!Shizuku.pingBinder()) {
        error("Serviço Shizuku não está ativo. Abra o app Shizuku e inicie o serviço.")
      }
      if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
        refreshStatus(explicitGranted = true)
        return@runCatching
      }
      if (Shizuku.isPreV11()) {
        error("Versão do Shizuku muito antiga. Atualize para a versão 11 ou superior.")
      }
      Shizuku.requestPermission(0)
    }
  }

  suspend fun executeShell(
    command: String,
    timeoutSeconds: Long = 25L,
    onOutputLine: suspend (String) -> Unit,
  ): Result<Int> =
    withContext(Dispatchers.IO) {
      runCatching {
        refreshStatus()
        if (!Shizuku.pingBinder()) {
          error("Shizuku desconectado. Inicie o Shizuku antes de executar.")
        }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
          error("Permissão do Shizuku negada. Toque no status do Shizuku para autorizar.")
        }

        val normalizedCmd = command.replace("\r\n", "\n").replace("\r", "\n")

        val newProcessMethod =
          Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java,
          )
        newProcessMethod.isAccessible = true

        val processObj =
          newProcessMethod.invoke(null, arrayOf("sh", "-c", normalizedCmd), null, null)
            ?: error("Falha ao criar processo remoto via Shizuku.")
        val process = processObj as Process

        try {
          coroutineScope {
            val stdoutJob = async(Dispatchers.IO) {
              runCatching {
                BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
                  var line: String?
                  while (reader.readLine().also { line = it } != null) {
                    line?.let { onOutputLine(it) }
                  }
                }
              }
            }
            val stderrJob = async(Dispatchers.IO) {
              runCatching {
                BufferedReader(InputStreamReader(process.errorStream)).use { reader ->
                  var line: String?
                  while (reader.readLine().also { line = it } != null) {
                    line?.let { onOutputLine("[stderr] $it") }
                  }
                }
              }
            }

            val finished = process.waitFor(timeoutSeconds, TimeUnit.SECONDS)
            if (!finished) {
              runCatching { process.destroy() }
              onOutputLine("[aviso] Tempo limite de ${timeoutSeconds}s atingido; processo encerrado.")
            }

            stdoutJob.await()
            stderrJob.await()

            if (finished) process.exitValue() else 124
          }
        } finally {
          runCatching { process.destroy() }
        }
      }
    }

  suspend fun executeModule(
    module: GeneratedModule,
    onOutputLine: suspend (String) -> Unit,
  ): Result<Int> {
    val script =
      buildString {
          append("#!/system/bin/sh\n")
          append("echo \"[Raylan Module AI] Executando ${module.name} (${module.id})\"\n")
          append("echo \"[Shizuku] UID atual: $(id -u)\"\n")
          append("MODDIR=\"/data/local/tmp/raylan_${module.id}\"\n")
          append("mkdir -p \"\$MODDIR\" 2>/dev/null || true\n\n")
          append("# --- ACTION.SH ---\n")
          append(
            module.actionSh
              .replace("\r\n", "\n")
              .replace("\r", "\n")
              .replace("#!/system/bin/sh", "")
              .trim(),
          )
          append("\n\n")
          append("# --- SERVICE.SH ---\n")
          append(
            module.serviceSh
              .replace("\r\n", "\n")
              .replace("\r", "\n")
              .replace("#!/system/bin/sh", "")
              .trim(),
          )
          append("\n\necho \"[Raylan Module AI] Otimizações aplicadas com sucesso.\"\n")
        }
        .replace("\r\n", "\n")
        .replace("\r", "\n")

    return executeShell(command = script, timeoutSeconds = 25L, onOutputLine = onOutputLine)
  }
}

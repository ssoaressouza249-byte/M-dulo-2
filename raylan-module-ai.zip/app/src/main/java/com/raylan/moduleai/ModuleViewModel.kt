package com.raylan.moduleai

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class RaylanUiState(
  val promptText: String = "",
  val isGenerating: Boolean = false,
  val apiKeyConfigured: Boolean = false,
  val currentApiKey: String = "",
  val latestModule: GeneratedModule? = null,
  val moduleHistory: List<GeneratedModule> = emptyList(),
  val console: ExecutionConsoleState = ExecutionConsoleState(),
  val feedbackMessage: String? = null,
  val isErrorFeedback: Boolean = false,
)

class ModuleViewModel(application: Application) : AndroidViewModel(application) {

  private val shizukuExecutor = ShizukuExecutor()
  private val aiEngine = ModuleAiEngine(application)
  private val zipBuilder = ModuleZipBuilder(application)

  val shizukuStatus: StateFlow<ShizukuStatus> = shizukuExecutor.status

  private val _uiState =
    MutableStateFlow(
      RaylanUiState(
        apiKeyConfigured = aiEngine.hasApiKey(),
        currentApiKey = aiEngine.getApiKey(),
      ),
    )
  val uiState: StateFlow<RaylanUiState> = _uiState.asStateFlow()

  val quickPresets: List<QuickChipPreset> =
    listOf(
      QuickChipPreset("+RAM & zRAM", "otimizar RAM, limpar cache e ajustar zRAM"),
      QuickChipPreset("+CPU & GPU Max", "aumentar desempenho máximo de CPU e GPU SkiaGL"),
      QuickChipPreset("+Toque Ultra Rápido", "deixar o toque ultra rápido e animações ágeis"),
      QuickChipPreset("+120 FPS Jogos", "travar 120 FPS em jogos com modo performance"),
      QuickChipPreset("+Modo Gelo", "ativar modo gelo para reduzir aquecimento térmico"),
    )

  init {
    shizukuExecutor.registerListeners()
  }

  override fun onCleared() {
    super.onCleared()
    shizukuExecutor.unregisterListeners()
  }

  fun refreshShizukuStatus() {
    shizukuExecutor.refreshStatus()
  }

  fun requestShizukuPermission() {
    shizukuExecutor.requestPermission().onFailure { error ->
      showFeedback(error.message ?: "Não foi possível solicitar permissão ao Shizuku.", isError = true)
    }
  }

  fun updatePrompt(newText: String) {
    _uiState.update { it.copy(promptText = newText) }
  }

  fun appendPreset(fragment: String) {
    _uiState.update { state ->
      val current = state.promptText.trim()
      val updated =
        when {
          current.isEmpty() -> "Cria um módulo para $fragment"
          current.contains(fragment, ignoreCase = true) -> current
          current.endsWith(",") || current.endsWith(".") -> "$current $fragment"
          else -> "$current, $fragment"
        }
      state.copy(promptText = updated)
    }
  }

  fun saveApiKey(key: String) {
    aiEngine.saveApiKey(key)
    val saved = aiEngine.getApiKey()
    _uiState.update {
      it.copy(
        apiKeyConfigured = saved.isNotBlank(),
        currentApiKey = saved,
      )
    }
    showFeedback(
      if (saved.isNotBlank()) "Chave Gemini API salva com sucesso."
      else "Chave removida. Usando Motor Local Inteligente.",
      isError = false,
    )
  }

  fun createModule() {
    if (_uiState.value.isGenerating) return
    val currentPrompt = _uiState.value.promptText.trim()

    viewModelScope.launch {
      _uiState.update { it.copy(isGenerating = true, feedbackMessage = null) }

      runCatching {
          val generated = aiEngine.generateModule(currentPrompt)
          val zipOutput = zipBuilder.buildAndSaveToDownloads(generated).getOrThrow()
          generated.copy(
            zipFileName = zipOutput.fileName,
            downloadsDisplayPath = zipOutput.downloadsDisplayPath,
            shareUriString = zipOutput.shareUriString,
          )
        }
        .onSuccess { readyModule ->
          _uiState.update { state ->
            val updatedHistory =
              (listOf(readyModule) + state.moduleHistory.filterNot { it.id == readyModule.id && it.zipFileName == readyModule.zipFileName })
                .take(10)
            state.copy(
              isGenerating = false,
              latestModule = readyModule,
              moduleHistory = updatedHistory,
              feedbackMessage = "Módulo salvo em ${readyModule.downloadsDisplayPath}",
              isErrorFeedback = false,
            )
          }
        }
        .onFailure { error ->
          _uiState.update {
            it.copy(
              isGenerating = false,
              feedbackMessage = "Erro ao gerar módulo: ${error.message ?: "falha inesperada"}",
              isErrorFeedback = true,
            )
          }
        }
    }
  }

  fun selectHistoryModule(module: GeneratedModule) {
    _uiState.update { it.copy(latestModule = module) }
  }

  fun executeModuleViaShizuku(module: GeneratedModule) {
    if (_uiState.value.console.isRunning) return

    shizukuExecutor.refreshStatus()
    val status = shizukuExecutor.status.value
    if (status.state == ShizukuConnectionState.CONNECTED_NO_PERMISSION) {
      requestShizukuPermission()
      showFeedback("Autorize o Shizuku na janela exibida e tente novamente.", isError = true)
      return
    }
    if (status.state == ShizukuConnectionState.DISCONNECTED) {
      showFeedback("Shizuku desconectado. Inicie o serviço Shizuku no dispositivo.", isError = true)
      return
    }

    viewModelScope.launch {
      _uiState.update {
        it.copy(
          console =
            ExecutionConsoleState(
              isRunning = true,
              activeModuleName = module.name,
              lines = listOf("$ shizuku exec ${module.id}.sh"),
              exitCode = null,
            ),
        )
      }

      val result =
        shizukuExecutor.executeModule(module) { outputLine ->
          _uiState.update { state ->
            val currentLines = state.console.lines
            val updatedLines = (currentLines + outputLine).takeLast(120)
            state.copy(console = state.console.copy(lines = updatedLines))
          }
        }

      result
        .onSuccess { code ->
          _uiState.update { state ->
            val footer =
              if (code == 0) "[✓] Execução finalizada (código 0)"
              else "[!] Finalizado com código $code"
            state.copy(
              console =
                state.console.copy(
                  isRunning = false,
                  lines = (state.console.lines + footer).takeLast(120),
                  exitCode = code,
                ),
            )
          }
        }
        .onFailure { error ->
          _uiState.update { state ->
            state.copy(
              console =
                state.console.copy(
                  isRunning = false,
                  lines =
                    (state.console.lines + "[erro] ${error.message ?: "Falha na execução"}")
                      .takeLast(120),
                  exitCode = -1,
                ),
            )
          }
        }
    }
  }

  fun clearFeedback() {
    _uiState.update { it.copy(feedbackMessage = null) }
  }

  private fun showFeedback(message: String, isError: Boolean) {
    _uiState.update { it.copy(feedbackMessage = message, isErrorFeedback = isError) }
  }
}

package com.raylan.moduleai.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val OledNeonColorScheme = darkColorScheme(
  primary = NeonGreen,
  onPrimary = OnNeonGreen,
  primaryContainer = NeonGreenTint,
  onPrimaryContainer = NeonGreen,
  secondary = NeonGreenDim,
  onSecondary = OnNeonGreen,
  background = OledBlack,
  onBackground = PureWhite,
  surface = CardSurface,
  onSurface = PureWhite,
  surfaceVariant = CardSurfaceElevated,
  onSurfaceVariant = MutedText,
  outline = SubtleBorder,
  error = StatusRed,
  onError = PureWhite,
)

@Composable
fun RaylanModuleAiTheme(content: @Composable () -> Unit) {
  MaterialTheme(
    colorScheme = OledNeonColorScheme,
    typography = RaylanTypography,
    content = content,
  )
}

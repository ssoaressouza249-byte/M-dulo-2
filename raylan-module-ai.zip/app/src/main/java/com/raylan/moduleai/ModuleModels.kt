package com.raylan.moduleai

enum class GenerationSource {
  GEMINI_ONLINE,
  LOCAL_ENGINE,
}

data class GeneratedModule(
  val id: String,
  val name: String,
  val version: String,
  val versionCode: String,
  val author: String,
  val description: String,
  val serviceSh: String,
  val actionSh: String,
  val systemProp: String,
  val uninstallSh: String,
  val promptUsed: String,
  val generatedBy: GenerationSource,
  val modelUsed: String,
  val zipFileName: String = "",
  val downloadsDisplayPath: String = "",
  val shareUriString: String? = null,
  val createdAtMillis: Long = System.currentTimeMillis(),
) {
  fun toModuleProp(): String =
    buildString {
        append("id=").append(id).append('\n')
        append("name=").append(name).append('\n')
        append("version=").append(version).append('\n')
        append("versionCode=").append(versionCode).append('\n')
        append("author=").append(author).append('\n')
        append("description=").append(description.replace('\n', ' ').trim()).append('\n')
      }
      .replace("\r\n", "\n")
      .replace("\r", "\n")
}

enum class ShizukuConnectionState {
  CONNECTED_GRANTED,
  CONNECTED_NO_PERMISSION,
  DISCONNECTED,
}

data class ShizukuStatus(
  val state: ShizukuConnectionState = ShizukuConnectionState.DISCONNECTED,
  val uid: Int = -1,
  val binderAlive: Boolean = false,
)

data class ExecutionConsoleState(
  val isRunning: Boolean = false,
  val activeModuleName: String? = null,
  val lines: List<String> = emptyList(),
  val exitCode: Int? = null,
)

data class QuickChipPreset(
  val label: String,
  val promptFragment: String,
)

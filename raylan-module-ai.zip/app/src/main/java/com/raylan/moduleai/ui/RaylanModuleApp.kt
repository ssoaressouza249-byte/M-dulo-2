package com.raylan.moduleai.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.raylan.moduleai.ExecutionConsoleState
import com.raylan.moduleai.GeneratedModule
import com.raylan.moduleai.GenerationSource
import com.raylan.moduleai.ModuleViewModel
import com.raylan.moduleai.QuickChipPreset
import com.raylan.moduleai.R
import com.raylan.moduleai.ShizukuConnectionState
import com.raylan.moduleai.ShizukuStatus
import com.raylan.moduleai.ui.theme.CardSurface
import com.raylan.moduleai.ui.theme.CardSurfaceElevated
import com.raylan.moduleai.ui.theme.MutedText
import com.raylan.moduleai.ui.theme.NeonGreen
import com.raylan.moduleai.ui.theme.NeonGreenTint
import com.raylan.moduleai.ui.theme.OledBlack
import com.raylan.moduleai.ui.theme.OnNeonGreen
import com.raylan.moduleai.ui.theme.PureWhite
import com.raylan.moduleai.ui.theme.StatusAmber
import com.raylan.moduleai.ui.theme.StatusRed
import com.raylan.moduleai.ui.theme.SubtleBorder
import com.raylan.moduleai.ui.theme.TerminalBg

@Composable
fun RaylanModuleApp(viewModel: ModuleViewModel) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val shizukuStatus by viewModel.shizukuStatus.collectAsStateWithLifecycle()
  val context = LocalContext.current

  var showApiKeyDialog by remember { mutableStateOf(false) }
  var detailsModule by remember { mutableStateOf<GeneratedModule?>(null) }

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    containerColor = OledBlack,
    contentWindowInsets = WindowInsets.safeDrawing,
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(
          Brush.verticalGradient(
            colors = listOf(Color(0xFF07120C), OledBlack, OledBlack),
          ),
        )
        .padding(innerPadding),
      contentAlignment = Alignment.TopCenter,
    ) {
      LazyColumn(
        modifier = Modifier.widthIn(max = 620.dp).fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        item(key = "header") {
          HeaderSection(
            shizukuStatus = shizukuStatus,
            apiKeyConfigured = uiState.apiKeyConfigured,
            onShizukuBadgeClick = {
              when (shizukuStatus.state) {
                ShizukuConnectionState.CONNECTED_NO_PERMISSION -> viewModel.requestShizukuPermission()
                else -> viewModel.refreshShizukuStatus()
              }
            },
            onApiKeyClick = { showApiKeyDialog = true },
          )
        }

        if (uiState.feedbackMessage != null) {
          item(key = "feedback") {
            FeedbackBanner(
              message = uiState.feedbackMessage.orEmpty(),
              isError = uiState.isErrorFeedback,
              onDismiss = { viewModel.clearFeedback() },
            )
          }
        }

        item(key = "creation_card") {
          ModuleCreationCard(
            promptText = uiState.promptText,
            presets = viewModel.quickPresets,
            isGenerating = uiState.isGenerating,
            onPromptChange = viewModel::updatePrompt,
            onPresetClick = viewModel::appendPreset,
            onClearClick = { viewModel.updatePrompt("") },
            onCreateClick = viewModel::createModule,
          )
        }

        if (uiState.latestModule != null) {
          item(key = "ready_module") {
            val module = uiState.latestModule!!
            AnimatedVisibility(
              visible = true,
              enter = fadeIn() + expandVertically(),
              exit = fadeOut() + shrinkVertically(),
            ) {
              ReadyModuleCard(
                module = module,
                isExecuting = uiState.console.isRunning,
                onExecuteClick = { viewModel.executeModuleViaShizuku(module) },
                onShareClick = { shareOrOpenZip(context, module) },
                onDetailsClick = { detailsModule = module },
              )
            }
          }
        }

        if (uiState.console.lines.isNotEmpty() || uiState.console.isRunning) {
          item(key = "shizuku_console") {
            ShizukuConsoleCard(console = uiState.console)
          }
        }

        if (uiState.moduleHistory.isNotEmpty()) {
          item(key = "history_header") {
            Row(
              modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Text(
                text = "HISTÓRICO DA SESSÃO",
                style = MaterialTheme.typography.labelMedium,
                color = MutedText,
                letterSpacing = 1.sp,
              )
              Text(
                text = "${uiState.moduleHistory.size} módulo(s)",
                style = MaterialTheme.typography.labelSmall,
                color = NeonGreen,
              )
            }
          }

          items(
            items = uiState.moduleHistory,
            key = { "${it.id}_${it.createdAtMillis}" },
          ) { itemModule ->
            HistoryModuleRow(
              module = itemModule,
              isSelected = uiState.latestModule?.createdAtMillis == itemModule.createdAtMillis,
              isExecuting = uiState.console.isRunning,
              onSelect = { viewModel.selectHistoryModule(itemModule) },
              onQuickRun = { viewModel.executeModuleViaShizuku(itemModule) },
            )
          }
        }

        item(key = "footer") {
          FooterCredits()
        }
      }
    }
  }

  if (showApiKeyDialog) {
    ApiKeyConfigDialog(
      currentKey = uiState.currentApiKey,
      onDismiss = { showApiKeyDialog = false },
      onSave = { newKey ->
        viewModel.saveApiKey(newKey)
        showApiKeyDialog = false
      },
    )
  }

  if (detailsModule != null) {
    TechnicalDetailsDialog(
      module = detailsModule!!,
      onDismiss = { detailsModule = null },
    )
  }
}

@Composable
private fun HeaderSection(
  shizukuStatus: ShizukuStatus,
  apiKeyConfigured: Boolean,
  onShizukuBadgeClick: () -> Unit,
  onApiKeyClick: () -> Unit,
) {
  Column(
    modifier = Modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(
        modifier = Modifier.weight(1f),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        BrandCoreEmblem(modifier = Modifier.size(42.dp))
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = stringResource(R.string.header_title),
            style = MaterialTheme.typography.headlineMedium,
            color = PureWhite,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Text(
            text = stringResource(R.string.header_subtitle),
            style = MaterialTheme.typography.bodyMedium,
            color = NeonGreen,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }

      Spacer(modifier = Modifier.width(8.dp))

      Surface(
        onClick = onApiKeyClick,
        modifier = Modifier
          .minimumInteractiveComponentSize()
          .testTag("api_key_button"),
        shape = RoundedCornerShape(12.dp),
        color = if (apiKeyConfigured) NeonGreenTint else CardSurface,
        border = BorderStroke(1.dp, if (apiKeyConfigured) NeonGreen else SubtleBorder),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          KeyCanvasIcon(
            tint = if (apiKeyConfigured) NeonGreen else MutedText,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(4.dp))
          Icon(
            imageVector = Icons.Default.Settings,
            contentDescription = "Configurar Gemini API Key",
            tint = if (apiKeyConfigured) NeonGreen else MutedText,
            modifier = Modifier.size(16.dp),
          )
        }
      }
    }

    // Status row: Shizuku UID badge + AI Mode badge
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      val (badgeLabel, badgeColor, dotColor) =
        when (shizukuStatus.state) {
          ShizukuConnectionState.CONNECTED_GRANTED -> {
            val uidText = if (shizukuStatus.uid >= 0) "UID ${shizukuStatus.uid}" else "UID 2000"
            Triple("Shizuku: Conectado ($uidText)", NeonGreen, NeonGreen)
          }
          ShizukuConnectionState.CONNECTED_NO_PERMISSION ->
            Triple("Shizuku: Toque p/ Autorizar", StatusAmber, StatusAmber)
          ShizukuConnectionState.DISCONNECTED ->
            Triple("Shizuku: Desconectado", StatusRed, StatusRed)
        }

      Surface(
        onClick = onShizukuBadgeClick,
        modifier = Modifier
          .weight(1f)
          .minimumInteractiveComponentSize()
          .testTag("shizuku_status_badge"),
        shape = RoundedCornerShape(12.dp),
        color = CardSurface,
        border = BorderStroke(1.dp, badgeColor.copy(alpha = 0.45f)),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Box(
              modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(dotColor),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = badgeLabel,
              style = MaterialTheme.typography.labelMedium,
              color = PureWhite,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
          Icon(
            imageVector = Icons.Default.Refresh,
            contentDescription = "Atualizar status Shizuku",
            tint = MutedText,
            modifier = Modifier.size(16.dp),
          )
        }
      }

      Surface(
        shape = RoundedCornerShape(12.dp),
        color = CardSurface,
        border = BorderStroke(1.dp, SubtleBorder),
      ) {
        Text(
          text = if (apiKeyConfigured) "IA: Gemini" else "IA: Offline",
          style = MaterialTheme.typography.labelSmall,
          color = if (apiKeyConfigured) NeonGreen else MutedText,
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 11.dp),
        )
      }
    }
  }
}

@Composable
private fun FeedbackBanner(
  message: String,
  isError: Boolean,
  onDismiss: () -> Unit,
) {
  val accent = if (isError) StatusRed else NeonGreen
  Surface(
    shape = RoundedCornerShape(12.dp),
    color = accent.copy(alpha = 0.12f),
    border = BorderStroke(1.dp, accent.copy(alpha = 0.45f)),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Icon(
        imageVector = if (isError) Icons.Default.Warning else Icons.Default.CheckCircle,
        contentDescription = null,
        tint = accent,
        modifier = Modifier.size(18.dp),
      )
      Spacer(modifier = Modifier.width(10.dp))
      Text(
        text = message,
        style = MaterialTheme.typography.bodyMedium,
        color = PureWhite,
        modifier = Modifier.weight(1f),
      )
      IconButton(
        onClick = onDismiss,
        modifier = Modifier.size(36.dp),
      ) {
        Icon(
          imageVector = Icons.Default.Close,
          contentDescription = "Fechar aviso",
          tint = MutedText,
          modifier = Modifier.size(16.dp),
        )
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ModuleCreationCard(
  promptText: String,
  presets: List<QuickChipPreset>,
  isGenerating: Boolean,
  onPromptChange: (String) -> Unit,
  onPresetClick: (String) -> Unit,
  onClearClick: () -> Unit,
  onCreateClick: () -> Unit,
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(containerColor = CardSurface),
    border = BorderStroke(1.dp, SubtleBorder),
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Text(
          text = "O que você quer otimizar hoje?",
          style = MaterialTheme.typography.titleMedium,
          color = PureWhite,
        )
        if (promptText.isNotBlank() && !isGenerating) {
          IconButton(
            onClick = onClearClick,
            modifier = Modifier.size(36.dp).testTag("clear_prompt_button"),
          ) {
            Icon(
              imageVector = Icons.Default.Clear,
              contentDescription = "Limpar texto",
              tint = MutedText,
              modifier = Modifier.size(18.dp),
            )
          }
        }
      }

      OutlinedTextField(
        value = promptText,
        onValueChange = onPromptChange,
        enabled = !isGenerating,
        modifier = Modifier
          .fillMaxWidth()
          .heightIn(min = 112.dp, max = 180.dp)
          .testTag("prompt_input"),
        placeholder = {
          Text(
            text = stringResource(R.string.prompt_placeholder),
            style = MaterialTheme.typography.bodyMedium,
            color = MutedText.copy(alpha = 0.72f),
          )
        },
        textStyle = MaterialTheme.typography.bodyLarge.copy(color = PureWhite),
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = NeonGreen,
          unfocusedBorderColor = SubtleBorder,
          focusedContainerColor = TerminalBg,
          unfocusedContainerColor = TerminalBg,
          cursorColor = NeonGreen,
        ),
        maxLines = 6,
      )

      Text(
        text = "Atalhos rápidos (toque para somar):",
        style = MaterialTheme.typography.labelSmall,
        color = MutedText,
      )

      FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        presets.forEach { preset ->
          val active = promptText.contains(preset.promptFragment, ignoreCase = true)
          Surface(
            onClick = { if (!isGenerating) onPresetClick(preset.promptFragment) },
            modifier = Modifier
              .minimumInteractiveComponentSize()
              .testTag("preset_chip_${preset.label}"),
            shape = RoundedCornerShape(10.dp),
            color = if (active) NeonGreenTint else CardSurfaceElevated,
            border = BorderStroke(1.dp, if (active) NeonGreen else SubtleBorder),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 9.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector = Icons.Default.Add,
                contentDescription = null,
                tint = if (active) NeonGreen else MutedText,
                modifier = Modifier.size(14.dp),
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = preset.label.removePrefix("+"),
                style = MaterialTheme.typography.labelMedium,
                color = if (active) NeonGreen else PureWhite,
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(2.dp))

      Button(
        onClick = onCreateClick,
        enabled = !isGenerating,
        modifier = Modifier
          .fillMaxWidth()
          .height(54.dp)
          .testTag("create_module_button"),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = NeonGreen,
          contentColor = OnNeonGreen,
          disabledContainerColor = NeonGreen.copy(alpha = 0.35f),
          disabledContentColor = OnNeonGreen,
        ),
      ) {
        if (isGenerating) {
          GeneratingPulseLoader()
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = "MONTANDO MÓDULO (.ZIP)...",
            style = MaterialTheme.typography.labelLarge,
          )
        } else {
          ZipBoxCanvasIcon(tint = OnNeonGreen, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = stringResource(R.string.btn_create_module),
            style = MaterialTheme.typography.labelLarge,
          )
        }
      }
    }
  }
}

@Composable
private fun ReadyModuleCard(
  module: GeneratedModule,
  isExecuting: Boolean,
  onExecuteClick: () -> Unit,
  onShareClick: () -> Unit,
  onDetailsClick: () -> Unit,
) {
  Card(
    modifier = Modifier.fillMaxWidth().testTag("ready_module_card"),
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(containerColor = CardSurface),
    border = BorderStroke(1.dp, NeonGreen.copy(alpha = 0.65f)),
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f),
        ) {
          Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = "Módulo pronto",
            tint = NeonGreen,
            modifier = Modifier.size(22.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "MÓDULO PRONTO",
            style = MaterialTheme.typography.labelMedium,
            color = NeonGreen,
            letterSpacing = 0.8.sp,
          )
        }

        Surface(
          shape = RoundedCornerShape(8.dp),
          color = NeonGreenTint,
          border = BorderStroke(1.dp, NeonGreen.copy(alpha = 0.4f)),
        ) {
          Text(
            text =
              if (module.generatedBy == GenerationSource.GEMINI_ONLINE) "Gemini AI"
              else "Motor Local",
            style = MaterialTheme.typography.labelSmall,
            color = NeonGreen,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
          )
        }
      }

      Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
          text = module.name,
          style = MaterialTheme.typography.titleMedium,
          color = PureWhite,
        )
        Text(
          text = "ID: ${module.id}  •  Autor: ${module.author}  •  ${module.version}",
          style = MaterialTheme.typography.labelSmall,
          color = MutedText,
        )
      }

      Surface(
        shape = RoundedCornerShape(10.dp),
        color = TerminalBg,
        border = BorderStroke(1.dp, SubtleBorder),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text(
            text = module.description,
            style = MaterialTheme.typography.bodyMedium,
            color = PureWhite.copy(alpha = 0.92f),
          )
          HorizontalDivider(color = SubtleBorder)
          Text(
            text = "Salvo em: ${module.downloadsDisplayPath}",
            style = MaterialTheme.typography.labelSmall,
            color = NeonGreen,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }

      // Action 1: Execute via Shizuku
      Button(
        onClick = onExecuteClick,
        enabled = !isExecuting,
        modifier = Modifier
          .fillMaxWidth()
          .height(50.dp)
          .testTag("execute_shizuku_button"),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = NeonGreen,
          contentColor = OnNeonGreen,
        ),
      ) {
        if (isExecuting) {
          CircularProgressIndicator(
            modifier = Modifier.size(18.dp),
            color = OnNeonGreen,
            strokeWidth = 2.dp,
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "EXECUTANDO VIA SHIZUKU...",
            style = MaterialTheme.typography.labelLarge,
          )
        } else {
          Icon(
            imageVector = Icons.Default.PlayArrow,
            contentDescription = null,
            modifier = Modifier.size(20.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = stringResource(R.string.btn_execute_shizuku),
            style = MaterialTheme.typography.labelLarge,
          )
        }
      }

      // Action 2: Share / Open ZIP + Technical Details button
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        OutlinedButton(
          onClick = onShareClick,
          modifier = Modifier
            .weight(1f)
            .height(48.dp)
            .testTag("share_zip_button"),
          shape = RoundedCornerShape(12.dp),
          border = BorderStroke(1.dp, NeonGreen.copy(alpha = 0.65f)),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = PureWhite),
        ) {
          Icon(
            imageVector = Icons.Default.Share,
            contentDescription = null,
            tint = NeonGreen,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = stringResource(R.string.btn_share_zip),
            style = MaterialTheme.typography.labelMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }

        OutlinedButton(
          onClick = onDetailsClick,
          modifier = Modifier
            .height(48.dp)
            .testTag("technical_details_button"),
          shape = RoundedCornerShape(12.dp),
          border = BorderStroke(1.dp, SubtleBorder),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = MutedText),
        ) {
          Icon(
            imageVector = Icons.Default.Info,
            contentDescription = "Ver detalhes técnicos",
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "Detalhes",
            style = MaterialTheme.typography.labelMedium,
          )
        }
      }
    }
  }
}

@Composable
private fun ShizukuConsoleCard(console: ExecutionConsoleState) {
  Card(
    modifier = Modifier.fillMaxWidth().testTag("shizuku_console_card"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = TerminalBg),
    border = BorderStroke(1.dp, SubtleBorder),
  ) {
    Column(
      modifier = Modifier.padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          TerminalCanvasIcon(tint = NeonGreen, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "CONSOLE SHIZUKU • ${console.activeModuleName.orEmpty()}",
            style = MaterialTheme.typography.labelSmall,
            color = NeonGreen,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
        if (console.exitCode != null) {
          Text(
            text = "exit ${console.exitCode}",
            style = MaterialTheme.typography.labelSmall,
            color = if (console.exitCode == 0) NeonGreen else StatusAmber,
          )
        }
      }

      HorizontalDivider(color = SubtleBorder)

      Column(
        modifier = Modifier
          .fillMaxWidth()
          .heightIn(min = 64.dp, max = 190.dp)
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(2.dp),
      ) {
        console.lines.forEach { line ->
          val lineColor =
            when {
              line.startsWith("[stderr]") || line.startsWith("[erro]") -> StatusRed
              line.startsWith("[✓]") || line.contains("sucesso", ignoreCase = true) -> NeonGreen
              else -> PureWhite.copy(alpha = 0.88f)
            }
          Text(
            text = line,
            style = MaterialTheme.typography.bodySmall,
            color = lineColor,
          )
        }
      }
    }
  }
}

@Composable
private fun HistoryModuleRow(
  module: GeneratedModule,
  isSelected: Boolean,
  isExecuting: Boolean,
  onSelect: () -> Unit,
  onQuickRun: () -> Unit,
) {
  Surface(
    onClick = onSelect,
    modifier = Modifier.fillMaxWidth().testTag("history_item_${module.id}"),
    shape = RoundedCornerShape(14.dp),
    color = if (isSelected) CardSurfaceElevated else CardSurface,
    border = BorderStroke(1.dp, if (isSelected) NeonGreen.copy(alpha = 0.5f) else SubtleBorder),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = module.name,
          style = MaterialTheme.typography.titleSmall,
          color = PureWhite,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        Text(
          text = module.downloadsDisplayPath,
          style = MaterialTheme.typography.labelSmall,
          color = MutedText,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }

      Spacer(modifier = Modifier.width(8.dp))

      Surface(
        onClick = { if (!isExecuting) onQuickRun() },
        modifier = Modifier.minimumInteractiveComponentSize(),
        shape = RoundedCornerShape(10.dp),
        color = NeonGreenTint,
        border = BorderStroke(1.dp, NeonGreen.copy(alpha = 0.45f)),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Icon(
            imageVector = Icons.Default.PlayArrow,
            contentDescription = "Executar ${module.name} via Shizuku",
            tint = NeonGreen,
            modifier = Modifier.size(16.dp),
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "Rodar",
            style = MaterialTheme.typography.labelSmall,
            color = NeonGreen,
          )
        }
      }
    }
  }
}

@Composable
private fun FooterCredits() {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(top = 8.dp, bottom = 12.dp)
      .navigationBarsPadding(),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    HorizontalDivider(color = SubtleBorder)
    Text(
      text = stringResource(R.string.footer_credits),
      style = MaterialTheme.typography.labelMedium,
      color = MutedText,
      letterSpacing = 0.8.sp,
    )
  }
}

@Composable
private fun ApiKeyConfigDialog(
  currentKey: String,
  onDismiss: () -> Unit,
  onSave: (String) -> Unit,
) {
  var keyInput by remember { mutableStateOf(currentKey) }
  var showKey by remember { mutableStateOf(false) }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = CardSurface,
    titleContentColor = PureWhite,
    textContentColor = MutedText,
    title = {
      Text(
        text = "Configurar Gemini API Key",
        style = MaterialTheme.typography.titleMedium,
      )
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text =
            "Opcional: informe sua chave da API Gemini para geração online avançada (modelo gemini-3.8-flash com fallback automático). Sem chave, o Motor Local Inteligente cria o módulo offline.",
          style = MaterialTheme.typography.bodyMedium,
        )
        OutlinedTextField(
          value = keyInput,
          onValueChange = { keyInput = it },
          singleLine = true,
          label = { Text("Gemini API Key") },
          placeholder = { Text("AIza...") },
          visualTransformation =
            if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
          trailingIcon = {
            TextButton(onClick = { showKey = !showKey }) {
              Text(
                text = if (showKey) "Ocultar" else "Ver",
                color = NeonGreen,
                style = MaterialTheme.typography.labelSmall,
              )
            }
          },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = NeonGreen,
            unfocusedBorderColor = SubtleBorder,
            focusedTextColor = PureWhite,
            unfocusedTextColor = PureWhite,
            cursorColor = NeonGreen,
          ),
          modifier = Modifier.fillMaxWidth().testTag("api_key_input"),
        )
      }
    },
    confirmButton = {
      Button(
        onClick = { onSave(keyInput) },
        colors = ButtonDefaults.buttonColors(
          containerColor = NeonGreen,
          contentColor = OnNeonGreen,
        ),
        modifier = Modifier.testTag("save_api_key_button"),
      ) {
        Text("Salvar", fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancelar", color = MutedText)
      }
    },
  )
}

@Composable
private fun TechnicalDetailsDialog(
  module: GeneratedModule,
  onDismiss: () -> Unit,
) {
  var selectedTab by remember { mutableStateOf(0) }
  val tabs = listOf("action.sh", "service.sh", "system.prop", "module.prop", "uninstall.sh")
  val contentText =
    when (selectedTab) {
      0 -> module.actionSh
      1 -> module.serviceSh
      2 -> module.systemProp
      3 -> module.toModuleProp()
      else -> module.uninstallSh
    }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = CardSurface,
    titleContentColor = PureWhite,
    title = {
      Text(
        text = "Detalhes Técnicos • ${module.id}",
        style = MaterialTheme.typography.titleMedium,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          tabs.forEachIndexed { index, title ->
            val selected = selectedTab == index
            Surface(
              onClick = { selectedTab = index },
              shape = RoundedCornerShape(8.dp),
              color = if (selected) NeonGreenTint else TerminalBg,
              border = BorderStroke(1.dp, if (selected) NeonGreen else SubtleBorder),
            ) {
              Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = if (selected) NeonGreen else MutedText,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
              )
            }
          }
        }

        Box(
          modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 160.dp, max = 300.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(TerminalBg)
            .border(1.dp, SubtleBorder, RoundedCornerShape(10.dp))
            .padding(10.dp)
            .verticalScroll(rememberScrollState()),
        ) {
          Text(
            text = contentText,
            style = MaterialTheme.typography.bodySmall,
            color = PureWhite.copy(alpha = 0.9f),
          )
        }
      }
    },
    confirmButton = {
      Button(
        onClick = onDismiss,
        colors = ButtonDefaults.buttonColors(
          containerColor = NeonGreen,
          contentColor = OnNeonGreen,
        ),
      ) {
        Text("Fechar", fontWeight = FontWeight.Bold)
      }
    },
  )
}

@Composable
private fun GeneratingPulseLoader() {
  val transition = rememberInfiniteTransition(label = "pulse")
  val alpha by
    transition.animateFloat(
      initialValue = 0.35f,
      targetValue = 1f,
      animationSpec =
        infiniteRepeatable(
          animation = tween(550, easing = LinearEasing),
          repeatMode = RepeatMode.Reverse,
        ),
      label = "pulseAlpha",
    )

  Canvas(modifier = Modifier.size(20.dp)) {
    drawCircle(
      color = OnNeonGreen.copy(alpha = alpha),
      radius = size.minDimension / 2.2f,
      style = Stroke(width = 2.4.dp.toPx()),
    )
    drawCircle(
      color = OnNeonGreen,
      radius = size.minDimension / 5f,
    )
  }
}

@Composable
private fun BrandCoreEmblem(modifier: Modifier = Modifier) {
  Canvas(modifier = modifier) {
    val w = size.width
    val h = size.height
    drawRoundRect(
      color = CardSurfaceElevated,
      topLeft = Offset.Zero,
      size = size,
      cornerRadius = CornerRadius(w * 0.24f, h * 0.24f),
    )
    drawRoundRect(
      color = NeonGreen.copy(alpha = 0.65f),
      topLeft = Offset.Zero,
      size = size,
      cornerRadius = CornerRadius(w * 0.24f, h * 0.24f),
      style = Stroke(width = 1.5.dp.toPx()),
    )
    // Inner microchip outline
    val pad = w * 0.2f
    drawRoundRect(
      color = PureWhite.copy(alpha = 0.85f),
      topLeft = Offset(pad, pad),
      size = Size(w - pad * 2f, h - pad * 2f),
      cornerRadius = CornerRadius(w * 0.08f, h * 0.08f),
      style = Stroke(width = 1.4.dp.toPx()),
    )
    // Neon lightning bolt
    val bolt =
      Path().apply {
        moveTo(w * 0.56f, h * 0.22f)
        lineTo(w * 0.36f, h * 0.53f)
        lineTo(w * 0.50f, h * 0.53f)
        lineTo(w * 0.44f, h * 0.78f)
        lineTo(w * 0.65f, h * 0.46f)
        lineTo(w * 0.51f, h * 0.46f)
        close()
      }
    drawPath(path = bolt, color = NeonGreen)
  }
}

@Composable
private fun KeyCanvasIcon(tint: Color, modifier: Modifier = Modifier) {
  Canvas(modifier = modifier) {
    val stroke = Stroke(width = 1.8.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
    val r = size.minDimension * 0.22f
    drawCircle(
      color = tint,
      radius = r,
      center = Offset(size.width * 0.3f, size.height * 0.5f),
      style = stroke,
    )
    drawLine(
      color = tint,
      start = Offset(size.width * 0.3f + r, size.height * 0.5f),
      end = Offset(size.width * 0.88f, size.height * 0.5f),
      strokeWidth = 1.8.dp.toPx(),
      cap = StrokeCap.Round,
    )
    drawLine(
      color = tint,
      start = Offset(size.width * 0.72f, size.height * 0.5f),
      end = Offset(size.width * 0.72f, size.height * 0.72f),
      strokeWidth = 1.8.dp.toPx(),
      cap = StrokeCap.Round,
    )
    drawLine(
      color = tint,
      start = Offset(size.width * 0.86f, size.height * 0.5f),
      end = Offset(size.width * 0.86f, size.height * 0.68f),
      strokeWidth = 1.8.dp.toPx(),
      cap = StrokeCap.Round,
    )
  }
}

@Composable
private fun ZipBoxCanvasIcon(tint: Color, modifier: Modifier = Modifier) {
  Canvas(modifier = modifier) {
    val stroke = Stroke(width = 1.8.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
    drawRoundRect(
      color = tint,
      topLeft = Offset(size.width * 0.14f, size.height * 0.16f),
      size = Size(size.width * 0.72f, size.height * 0.68f),
      cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx()),
      style = stroke,
    )
    drawLine(
      color = tint,
      start = Offset(size.width * 0.5f, size.height * 0.16f),
      end = Offset(size.width * 0.5f, size.height * 0.60f),
      strokeWidth = 1.8.dp.toPx(),
      cap = StrokeCap.Round,
    )
    drawLine(
      color = tint,
      start = Offset(size.width * 0.38f, size.height * 0.48f),
      end = Offset(size.width * 0.5f, size.height * 0.62f),
      strokeWidth = 1.8.dp.toPx(),
      cap = StrokeCap.Round,
    )
    drawLine(
      color = tint,
      start = Offset(size.width * 0.62f, size.height * 0.48f),
      end = Offset(size.width * 0.5f, size.height * 0.62f),
      strokeWidth = 1.8.dp.toPx(),
      cap = StrokeCap.Round,
    )
  }
}

@Composable
private fun TerminalCanvasIcon(tint: Color, modifier: Modifier = Modifier) {
  Canvas(modifier = modifier) {
    val stroke = 1.7.dp.toPx()
    drawLine(
      color = tint,
      start = Offset(size.width * 0.16f, size.height * 0.25f),
      end = Offset(size.width * 0.46f, size.height * 0.50f),
      strokeWidth = stroke,
      cap = StrokeCap.Round,
    )
    drawLine(
      color = tint,
      start = Offset(size.width * 0.46f, size.height * 0.50f),
      end = Offset(size.width * 0.16f, size.height * 0.75f),
      strokeWidth = stroke,
      cap = StrokeCap.Round,
    )
    drawLine(
      color = tint,
      start = Offset(size.width * 0.54f, size.height * 0.75f),
      end = Offset(size.width * 0.86f, size.height * 0.75f),
      strokeWidth = stroke,
      cap = StrokeCap.Round,
    )
  }
}

private fun shareOrOpenZip(context: Context, module: GeneratedModule) {
  runCatching {
    val uriString = module.shareUriString ?: return
    val uri = Uri.parse(uriString)
    val shareIntent =
      Intent(Intent.ACTION_SEND).apply {
        type = "application/zip"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, module.name)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      }
    val chooser =
      Intent.createChooser(shareIntent, "Abrir ou enviar ${module.zipFileName}").apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
    context.startActivity(chooser)
  }
}

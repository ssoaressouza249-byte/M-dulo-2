package com.raylan.moduleai

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit

class ModuleAiEngine(context: Context) {

  private val prefs =
    context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

  private val client: OkHttpClient =
    OkHttpClient.Builder()
      .connectTimeout(20, TimeUnit.SECONDS)
      .readTimeout(45, TimeUnit.SECONDS)
      .writeTimeout(20, TimeUnit.SECONDS)
      .build()

  fun getApiKey(): String =
    runCatching { prefs.getString(KEY_GEMINI_API, "").orEmpty().trim() }.getOrDefault("")

  fun saveApiKey(apiKey: String) {
    runCatching {
      prefs.edit().putString(KEY_GEMINI_API, apiKey.trim()).apply()
    }
  }

  fun hasApiKey(): Boolean = getApiKey().isNotBlank()

  suspend fun generateModule(userPrompt: String): GeneratedModule =
    withContext(Dispatchers.IO) {
      val cleanPrompt = userPrompt.trim().ifEmpty {
        "Otimização equilibrada de RAM, CPU, GPU e sensibilidade do toque para Android"
      }

      val apiKey = getApiKey()
      if (apiKey.isBlank()) {
        return@withContext generateOfflineModule(cleanPrompt)
      }

      val onlineResult = runCatching {
        requestGeminiWithFallback(apiKey = apiKey, userPrompt = cleanPrompt)
      }

      onlineResult.getOrElse {
        generateOfflineModule(cleanPrompt)
      }
    }

  private fun requestGeminiWithFallback(apiKey: String, userPrompt: String): GeneratedModule {
    val firstAttempt = callGeminiModel(PRIMARY_MODEL, apiKey, userPrompt)
    if (firstAttempt.httpCode == 404) {
      val fallbackAttempt = callGeminiModel(FALLBACK_MODEL, apiKey, userPrompt)
      if (fallbackAttempt.module != null) {
        return fallbackAttempt.module
      }
      error("Fallback Gemini falhou com HTTP ${fallbackAttempt.httpCode}")
    }
    if (firstAttempt.module != null) {
      return firstAttempt.module
    }
    error("Gemini falhou com HTTP ${firstAttempt.httpCode}")
  }

  private data class GeminiCallResult(
    val httpCode: Int,
    val module: GeneratedModule?,
  )

  private fun callGeminiModel(model: String, apiKey: String, userPrompt: String): GeminiCallResult {
    val url =
      "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"

    val requestJson =
      JSONObject().apply {
        put(
          "systemInstruction",
          JSONObject().apply {
            put(
              "parts",
              JSONArray().apply {
                put(JSONObject().put("text", SYSTEM_PROMPT))
              },
            )
          },
        )
        put(
          "contents",
          JSONArray().apply {
            put(
              JSONObject().apply {
                put("role", "user")
                put(
                  "parts",
                  JSONArray().apply {
                    put(
                      JSONObject().put(
                        "text",
                        "Pedido do usuário para o módulo Android: $userPrompt\nRetorne APENAS o JSON puro.",
                      ),
                    )
                  },
                )
              },
            )
          },
        )
        put(
          "generationConfig",
          JSONObject().apply {
            put("temperature", 0.35)
            put("responseMimeType", "application/json")
          },
        )
      }

    val mediaType = "application/json; charset=utf-8".toMediaType()
    val body = requestJson.toString().toRequestBody(mediaType)
    val request =
      Request.Builder()
        .url(url)
        .post(body)
        .addHeader("Content-Type", "application/json")
        .build()

    client.newCall(request).execute().use { response ->
      val code = response.code
      if (!response.isSuccessful) {
        return GeminiCallResult(httpCode = code, module = null)
      }
      val rawBody = response.body?.string().orEmpty()
      val parsed = parseGeminiJsonResponse(rawBody, userPrompt, model)
      return GeminiCallResult(httpCode = code, module = parsed)
    }
  }

  private fun parseGeminiJsonResponse(
    rawBody: String,
    userPrompt: String,
    model: String,
  ): GeneratedModule {
    val root = JSONObject(rawBody)
    val candidates = root.optJSONArray("candidates") ?: error("Sem candidates na resposta")
    if (candidates.length() == 0) error("Candidates vazio")

    val parts =
      candidates.getJSONObject(0).getJSONObject("content").getJSONArray("parts")
    val rawText = parts.getJSONObject(0).getString("text")
    val cleanedJson = stripMarkdownFences(rawText)
    val obj = JSONObject(cleanedJson)

    val safeId = sanitizeModuleId(obj.optString("id", ""))
    val name = obj.optString("name", "").trim().ifEmpty { "Raylan Turbo Module" }
    val version = obj.optString("version", "v1.0").trim().ifEmpty { "v1.0" }
    val versionCode = obj.optString("versionCode", "100").trim().ifEmpty { "100" }
    val description =
      obj.optString("description", "").trim().ifEmpty {
        "Módulo de otimização gerado automaticamente por Raylan Module AI."
      }

    val serviceSh = normalizeLf(obj.optString("service_sh", "")).ifBlank {
      buildDefaultServiceScript()
    }
    val actionSh = normalizeLf(obj.optString("action_sh", "")).ifBlank {
      buildDefaultActionScript()
    }
    val systemProp = normalizeLf(obj.optString("system_prop", "")).ifBlank {
      buildDefaultSystemProp()
    }
    val uninstallSh = normalizeLf(obj.optString("uninstall_sh", "")).ifBlank {
      buildDefaultUninstallScript()
    }

    return GeneratedModule(
      id = safeId,
      name = name,
      version = version,
      versionCode = versionCode,
      author = "Raylan",
      description = description,
      serviceSh = ensureShebang(serviceSh),
      actionSh = ensureShebang(actionSh),
      systemProp = systemProp,
      uninstallSh = ensureShebang(uninstallSh),
      promptUsed = userPrompt,
      generatedBy = GenerationSource.GEMINI_ONLINE,
      modelUsed = model,
    )
  }

  fun generateOfflineModule(userPrompt: String): GeneratedModule {
    val lower = userPrompt.lowercase(Locale.ROOT)

    val hasRam =
      containsAny(lower, "ram", "zram", "memória", "memoria", "multitarefa", "cache", "swap")
    val hasCpu =
      containsAny(lower, "cpu", "processador", "clock", "desempenho", "performance", "turbo")
    val hasGpu =
      containsAny(lower, "gpu", "gráfico", "grafico", "render", "skiagl", "vulkan", "hwui")
    val hasFps =
      containsAny(lower, "fps", "jogo", "jogos", "game", "120", "90hz", "lag", "ping")
    val hasTouch =
      containsAny(lower, "toque", "touch", "sensibilidade", "resposta", "tela", "scroll", "dpi")
    val hasBattery =
      containsAny(lower, "bateria", "economia", "doze", "standby", "energia", "autonomia")
    val hasCold =
      containsAny(lower, "gelo", "frio", "térmico", "termico", "resfriar", "temperatura", "cooler")

    val anyMatched = hasRam || hasCpu || hasGpu || hasFps || hasTouch || hasBattery || hasCold
    val enableRam = hasRam || !anyMatched
    val enableCpu = hasCpu || hasFps || !anyMatched
    val enableGpu = hasGpu || hasFps
    val enableFps = hasFps
    val enableTouch = hasTouch || !anyMatched
    val enableBattery = hasBattery
    val enableCold = hasCold

    val tags = mutableListOf<String>()
    if (enableRam) tags.add("RAM")
    if (enableCpu) tags.add("CPU")
    if (enableGpu) tags.add("GPU")
    if (enableFps) tags.add("120FPS")
    if (enableTouch) tags.add("Toque")
    if (enableCold) tags.add("Gelo")
    if (enableBattery) tags.add("Bateria")

    val moduleName =
      when {
        enableCold && !enableFps -> "Raylan Ice Cooling Pro"
        enableFps && enableGpu -> "Raylan 120FPS Pro Max"
        enableBattery && !enableFps -> "Raylan Eco Smart Boost"
        else -> "Raylan ${tags.take(3).joinToString(" ")} Boost"
      }

    val idSuffix =
      tags.joinToString("_") { it.lowercase(Locale.ROOT) }.ifEmpty { "smart_boost" }
    val moduleId = sanitizeModuleId("raylan_${idSuffix}")

    val descriptionParts = mutableListOf<String>()
    if (enableRam) descriptionParts.add("limpeza inteligente de RAM e ajuste zRAM")
    if (enableCpu) descriptionParts.add("modo de desempenho fixo de CPU")
    if (enableGpu) descriptionParts.add("aceleração SkiaGL/EGL de GPU")
    if (enableFps) descriptionParts.add("otimização de jogos para alto FPS")
    if (enableTouch) descriptionParts.add("resposta de toque rápida e animações ágeis")
    if (enableCold) descriptionParts.add("controle térmico anti-aquecimento")
    if (enableBattery) descriptionParts.add("otimização de standby e economia inteligente")

    val description =
      "Módulo AxManager/Shizuku com ${descriptionParts.joinToString(", ")}. Criado por Raylan."

    val serviceBuilder = StringBuilder()
    serviceBuilder.append("#!/system/bin/sh\n")
    serviceBuilder.append("# Raylan Module AI - Service Script (AxManager / Magisk / KSU)\n\n")

    val actionBuilder = StringBuilder()
    actionBuilder.append("#!/system/bin/sh\n")
    actionBuilder.append("# Raylan Module AI - Execução Imediata (Shizuku UID 2000 & Root)\n")
    actionBuilder.append("echo \"[Raylan] Aplicando perfil: $moduleName\"\n\n")

    val propBuilder = StringBuilder()
    propBuilder.append("# Raylan Module AI - System Properties\n")

    val uninstallBuilder = StringBuilder()
    uninstallBuilder.append("#!/system/bin/sh\n")
    uninstallBuilder.append("# Raylan Module AI - Restauração Segura\n")
    uninstallBuilder.append("cmd power set-fixed-performance-mode-enabled false 2>/dev/null || true\n")
    uninstallBuilder.append("cmd thermalservice reset 2>/dev/null || true\n")
    uninstallBuilder.append("settings put global window_animation_scale 1.0 2>/dev/null || true\n")
    uninstallBuilder.append("settings put global transition_animation_scale 1.0 2>/dev/null || true\n")
    uninstallBuilder.append("settings put global animator_duration_scale 1.0 2>/dev/null || true\n")
    uninstallBuilder.append("settings put system pointer_speed 0 2>/dev/null || true\n")

    if (enableCpu || enableFps) {
      val block = """
        echo "[CPU] Ativando modo de performance fixa..."
        cmd power set-fixed-performance-mode-enabled true 2>/dev/null || true
        if [ "$(id -u)" = "0" ]; then
          for gov in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
            [ -w "${'$'}gov" ] && echo "performance" > "${'$'}gov" 2>/dev/null || true
          done
        fi
      """.trimIndent()
      serviceBuilder.append(block).append("\n\n")
      actionBuilder.append(block).append("\n\n")
    }

    if (enableCold) {
      val coldBlock = """
        echo "[Gelo] Aplicando perfil térmico equilibrado..."
        cmd power set-fixed-performance-mode-enabled false 2>/dev/null || true
        cmd thermalservice override-status 0 2>/dev/null || true
        am kill-all 2>/dev/null || true
        if [ "$(id -u)" = "0" ]; then
          for gov in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
            [ -w "${'$'}gov" ] && echo "schedutil" > "${'$'}gov" 2>/dev/null || true
          done
        fi
      """.trimIndent()
      serviceBuilder.append(coldBlock).append("\n\n")
      actionBuilder.append(coldBlock).append("\n\n")
      propBuilder.append("debug.hwui.renderer=skiagl\n")
    } else if (enableCpu || enableFps || enableGpu) {
      val thermalBlock = """
        cmd thermalservice override-status 0 2>/dev/null || true
      """.trimIndent()
      serviceBuilder.append(thermalBlock).append("\n\n")
      actionBuilder.append(thermalBlock).append("\n\n")
    }

    if (enableRam) {
      val ramBlock = """
        echo "[RAM] Limpando processos em segundo plano e otimizando zRAM..."
        am kill-all 2>/dev/null || true
        cmd package trim-caches 512M 2>/dev/null || true
        if [ "$(id -u)" = "0" ]; then
          sync
          [ -w /proc/sys/vm/drop_caches ] && echo 3 > /proc/sys/vm/drop_caches 2>/dev/null || true
          [ -w /proc/sys/vm/swappiness ] && echo 60 > /proc/sys/vm/swappiness 2>/dev/null || true
          [ -w /sys/block/zram0/comp_algorithm ] && echo lz4 > /sys/block/zram0/comp_algorithm 2>/dev/null || true
        fi
      """.trimIndent()
      serviceBuilder.append(ramBlock).append("\n\n")
      actionBuilder.append(ramBlock).append("\n\n")
      propBuilder.append("ro.config.low_ram=false\n")
      propBuilder.append("persist.sys.purgeable_assets=1\n")
    }

    if (enableGpu || enableFps) {
      val gpuBlock = """
        echo "[GPU/FPS] Configurando pipeline SkiaGL e modo Game..."
        setprop debug.hwui.renderer skiagl 2>/dev/null || true
        setprop debug.egl.swapinterval 0 2>/dev/null || true
        setprop debug.sf.latch_unsignaled 1 2>/dev/null || true
        cmd game set --mode performance 2>/dev/null || true
      """.trimIndent()
      serviceBuilder.append(gpuBlock).append("\n\n")
      actionBuilder.append(gpuBlock).append("\n\n")
      propBuilder.append("debug.hwui.renderer=skiagl\n")
      propBuilder.append("debug.egl.swapinterval=0\n")
      propBuilder.append("debug.sf.latch_unsignaled=1\n")
      propBuilder.append("debug.performance.tuning=1\n")
    }

    if (enableTouch) {
      val touchBlock = """
        echo "[Toque] Acelerando resposta de toque e escalas de animação..."
        settings put system pointer_speed 7 2>/dev/null || true
        settings put global window_animation_scale 0.25 2>/dev/null || true
        settings put global transition_animation_scale 0.25 2>/dev/null || true
        settings put global animator_duration_scale 0.25 2>/dev/null || true
      """.trimIndent()
      serviceBuilder.append(touchBlock).append("\n\n")
      actionBuilder.append(touchBlock).append("\n\n")
      propBuilder.append("touch.pressure.scale=0.001\n")
      propBuilder.append("windowsmgr.max_events_per_sec=180\n")
    }

    if (enableBattery) {
      val batteryBlock = """
        echo "[Bateria] Aplicando otimizações de standby e compilação speed-profile..."
        cmd package compile -m speed-profile -a 2>/dev/null || true
        am set-standby-bucket com.android.chrome rare 2>/dev/null || true
        appops set com.raylan.moduleai RUN_IN_BACKGROUND allow 2>/dev/null || true
      """.trimIndent()
      serviceBuilder.append(batteryBlock).append("\n\n")
      actionBuilder.append(batteryBlock).append("\n\n")
      propBuilder.append("pm.sleep_mode=1\n")
      propBuilder.append("ro.ril.disable.power.collapse=0\n")
    } else {
      val compileBlock = """
        echo "[Sistema] Otimizando perfis de execução..."
        appops set com.raylan.moduleai RUN_IN_BACKGROUND allow 2>/dev/null || true
        cmd package compile -m speed-profile --check-prof false -f com.android.systemui 2>/dev/null || true
      """.trimIndent()
      serviceBuilder.append(compileBlock).append("\n\n")
      actionBuilder.append(compileBlock).append("\n\n")
    }

    actionBuilder.append("echo \"[Raylan] Finalizado com sucesso!\"\n")

    return GeneratedModule(
      id = moduleId,
      name = moduleName,
      version = "v1.0",
      versionCode = "100",
      author = "Raylan",
      description = description,
      serviceSh = normalizeLf(serviceBuilder.toString()),
      actionSh = normalizeLf(actionBuilder.toString()),
      systemProp = normalizeLf(propBuilder.toString()),
      uninstallSh = normalizeLf(uninstallBuilder.toString()),
      promptUsed = userPrompt,
      generatedBy = GenerationSource.LOCAL_ENGINE,
      modelUsed = "Raylan Local Engine",
    )
  }

  private fun containsAny(text: String, vararg terms: String): Boolean =
    terms.any { text.contains(it) }

  private fun stripMarkdownFences(raw: String): String {
    var trimmed = raw.trim()
    if (trimmed.startsWith("```")) {
      val firstNewline = trimmed.indexOf('\n')
      if (firstNewline != -1) {
        trimmed = trimmed.substring(firstNewline + 1)
      }
      if (trimmed.endsWith("```")) {
        trimmed = trimmed.substring(0, trimmed.length - 3)
      }
    }
    return trimmed.trim()
  }

  private fun sanitizeModuleId(rawId: String): String {
    val clean =
      rawId
        .lowercase(Locale.ROOT)
        .replace(Regex("[^a-z0-9_]+"), "_")
        .trim('_')
    return when {
      clean.isBlank() -> "raylan_turbo_module"
      !clean.startsWith("raylan_") -> "raylan_$clean"
      else -> clean
    }.take(48)
  }

  private fun normalizeLf(text: String): String =
    text.replace("\r\n", "\n").replace("\r", "\n").trimEnd() + "\n"

  private fun ensureShebang(script: String): String {
    val normalized = normalizeLf(script)
    return if (normalized.startsWith("#!")) {
      normalized
    } else {
      "#!/system/bin/sh\n$normalized"
    }
  }

  private fun buildDefaultServiceScript(): String =
    """
    #!/system/bin/sh
    cmd power set-fixed-performance-mode-enabled true 2>/dev/null || true
    cmd thermalservice override-status 0 2>/dev/null || true
    setprop debug.hwui.renderer skiagl 2>/dev/null || true
    setprop debug.egl.swapinterval 0 2>/dev/null || true
    setprop debug.sf.latch_unsignaled 1 2>/dev/null || true
    settings put system pointer_speed 7 2>/dev/null || true
    settings put global window_animation_scale 0.25 2>/dev/null || true
    settings put global transition_animation_scale 0.25 2>/dev/null || true
    settings put global animator_duration_scale 0.25 2>/dev/null || true
    if [ "$(id -u)" = "0" ]; then
      [ -w /proc/sys/vm/swappiness ] && echo 60 > /proc/sys/vm/swappiness 2>/dev/null || true
    fi
    """.trimIndent() + "\n"

  private fun buildDefaultActionScript(): String =
    """
    #!/system/bin/sh
    echo "[Raylan Module AI] Aplicando otimizações imediatas..."
    am kill-all 2>/dev/null || true
    cmd power set-fixed-performance-mode-enabled true 2>/dev/null || true
    settings put system pointer_speed 7 2>/dev/null || true
    echo "[Raylan Module AI] Concluído."
    """.trimIndent() + "\n"

  private fun buildDefaultSystemProp(): String =
    """
    debug.hwui.renderer=skiagl
    debug.egl.swapinterval=0
    debug.sf.latch_unsignaled=1
    """.trimIndent() + "\n"

  private fun buildDefaultUninstallScript(): String =
    """
    #!/system/bin/sh
    cmd power set-fixed-performance-mode-enabled false 2>/dev/null || true
    cmd thermalservice reset 2>/dev/null || true
    settings put global window_animation_scale 1.0 2>/dev/null || true
    settings put global transition_animation_scale 1.0 2>/dev/null || true
    settings put global animator_duration_scale 1.0 2>/dev/null || true
    settings put system pointer_speed 0 2>/dev/null || true
    """.trimIndent() + "\n"

  companion object {
    private const val PREFS_NAME = "raylan_module_ai_prefs"
    private const val KEY_GEMINI_API = "gemini_api_key"
    private const val PRIMARY_MODEL = "gemini-3.8-flash"
    private const val FALLBACK_MODEL = "gemini-2.5-flash"

    private val SYSTEM_PROMPT =
      """
      Você é o motor especialista de geração de módulos de otimização Android da suíte "Raylan Module AI".
      Gere um módulo completo e 100% funcional compatível com AxManager (Shizuku UID 2000) e gerenciadores Magisk/KernelSU/APatch.

      RETORNE ESTRITAMENTE UM ÚNICO OBJETO JSON PURO (sem markdown, sem crases, sem texto fora do JSON) com exatamente estas chaves:
      - "id": string minúscula sem espaços (apenas a-z, 0-9 e _, ex: "raylan_turbo_ram_cpu")
      - "name": nome comercial atraente do módulo em português
      - "version": "v1.0"
      - "versionCode": "100"
      - "author": "Raylan"
      - "description": resumo claro em português das otimizações aplicadas
      - "service_sh": script shell completo e avançado com quebras de linha Unix (\n)
      - "action_sh": script de execução imediata compatível com AxManager e Shizuku (com echo de progresso, sem loops infinitos)
      - "system_prop": propriedades sys/debug reais e válidas (chave=valor por linha)
      - "uninstall_sh": script de limpeza/restauração segura

      REGRAS OBRIGATÓRIAS NOS SCRIPTS:
      1. Use apenas comandos reais de alto desempenho do Android e UID 2000:
         - cmd power set-fixed-performance-mode-enabled true
         - cmd thermalservice override-status 0
         - cmd game set --mode performance
         - cmd package compile -m speed-profile / everything
         - am kill-all
         - am set-standby-bucket
         - appops set ... RUN_IN_BACKGROUND allow
         - setprop debug.hwui.renderer skiagl
         - setprop debug.egl.swapinterval 0
         - setprop debug.sf.latch_unsignaled 1
         - settings put system pointer_speed 7
         - settings put global window_animation_scale 0.25
         - settings put global transition_animation_scale 0.25
         - settings put global animator_duration_scale 0.25
      2. SEMPRE proteja comandos exclusivos de root (como /sys/block/zram0, /proc/sys/vm/*, vm.swappiness, /sys/devices/system/cpu/*) dentro de:
         if [ "${'$'}(id -u)" = "0" ]; then
           ...
         fi
         para nunca gerar erro de permissão no AxManager via Shizuku (UID 2000).
      3. Nunca bloqueie action_sh ou service_sh com loops infinitos (while true / sleep longo).
      4. Use exclusivamente quebras de linha Unix LF (\n) em todos os campos.
      """.trimIndent()
  }
}

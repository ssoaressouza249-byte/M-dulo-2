package com.raylan.moduleai.ui.theme

import androidx.compose.ui.graphics.Color

val OledBlack = Color(0xFF050505)
val CardSurface = Color(0xFF0F1210)
val CardSurfaceElevated = Color(0xFF141916)
val SubtleBorder = Color(0xFF1E2E24)
val NeonGreen = Color(0xFF00FF66)
val NeonGreenDim = Color(0xFF00C853)
val NeonGreenTint = Color(0x1A00FF66)
val OnNeonGreen = Color(0xFF031A0C)
val PureWhite = Color(0xFFFFFFFF)
val MutedText = Color(0xFF9EB0A6)
val TerminalBg = Color(0xFF080A09)
val StatusAmber = Color(0xFFFFB020)
val StatusRed = Color(0xFFFF4D4D)
val TamperRed = Color(0xFFB00020)

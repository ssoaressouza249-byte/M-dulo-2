package com.raylan.moduleai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.raylan.moduleai.ui.RaylanModuleApp
import com.raylan.moduleai.ui.theme.RaylanModuleAiTheme

class MainActivity : ComponentActivity() {

  private val viewModel: ModuleViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.dark(android.graphics.Color.parseColor("#050505")),
      navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.parseColor("#050505")),
    )

    val authentic = SecurityGuard.isAppAuthentic(this)

    setContent {
      RaylanModuleAiTheme {
        if (!authentic) {
          TamperedAppScreen(onUninstallClick = { SecurityGuard.launchUninstall(this) })
        } else {
          RaylanModuleApp(viewModel = viewModel)
        }
      }
    }
  }

  override fun onResume() {
    super.onResume()
    runCatching { viewModel.refreshShizukuStatus() }
  }
}

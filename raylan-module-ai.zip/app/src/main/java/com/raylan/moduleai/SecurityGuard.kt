package com.raylan.moduleai

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raylan.moduleai.ui.theme.TamperRed

object SecurityGuard {
  private const val EXPECTED_PACKAGE_NAME = "com.raylan.moduleai"
  private const val EXPECTED_LABEL_SUBSTRING = "Raylan Module AI"

  fun isAppAuthentic(context: Context): Boolean {
    return runCatching {
        val pkgOk = context.packageName == EXPECTED_PACKAGE_NAME
        val appLabel = context.applicationInfo.loadLabel(context.packageManager).toString()
        val labelOk = appLabel.contains(EXPECTED_LABEL_SUBSTRING)
        pkgOk && labelOk
      }
      .getOrDefault(false)
  }

  fun launchUninstall(context: Context) {
    runCatching {
      val intent =
        Intent(Intent.ACTION_DELETE, Uri.parse("package:${context.packageName}")).apply {
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
      context.startActivity(intent)
    }
  }
}

@Composable
fun TamperedAppScreen(onUninstallClick: () -> Unit) {
  BackHandler(enabled = true) {}

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(TamperRed)
      .systemBarsPadding()
      .padding(24.dp),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      modifier = Modifier.widthIn(max = 420.dp).fillMaxWidth(),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
    ) {
      Box(
        modifier = Modifier
          .size(84.dp)
          .background(Color.White.copy(alpha = 0.16f), CircleShape),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Default.Warning,
          contentDescription = "Alerta de segurança",
          tint = Color.White,
          modifier = Modifier.size(48.dp),
        )
      }

      Spacer(modifier = Modifier.height(24.dp))

      Text(
        text = stringResource(R.string.tampered_warning),
        color = Color.White,
        fontSize = 22.sp,
        fontWeight = FontWeight.ExtraBold,
        fontFamily = FontFamily.Default,
        textAlign = TextAlign.Center,
        lineHeight = 28.sp,
      )

      Spacer(modifier = Modifier.height(14.dp))

      Text(
        text = "Identidade do pacote ou nome oficial foi modificada. Por proteção contra clonagem, a execução foi bloqueada.",
        color = Color.White.copy(alpha = 0.9f),
        fontSize = 14.sp,
        fontFamily = FontFamily.Default,
        textAlign = TextAlign.Center,
        lineHeight = 20.sp,
      )

      Spacer(modifier = Modifier.height(32.dp))

      Button(
        onClick = onUninstallClick,
        modifier = Modifier
          .fillMaxWidth()
          .height(54.dp)
          .testTag("tampered_uninstall_button"),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = Color.White,
          contentColor = TamperRed,
        ),
      ) {
        Text(
          text = stringResource(R.string.btn_uninstall_now),
          fontWeight = FontWeight.ExtraBold,
          fontSize = 15.sp,
          letterSpacing = 0.6.sp,
        )
      }
    }
  }
}

package com.raylan.moduleai

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.charset.StandardCharsets
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class ZipBuildOutput(
  val fileName: String,
  val downloadsDisplayPath: String,
  val shareUriString: String?,
)

class ModuleZipBuilder(private val context: Context) {

  suspend fun buildAndSaveToDownloads(module: GeneratedModule): Result<ZipBuildOutput> =
    withContext(Dispatchers.IO) {
      runCatching {
        val safeBaseName = sanitizeFileName(module.name)
        val zipFileName = "${safeBaseName}.zip"
        val zipBytes = createModuleZipBytes(module)

        // 1. Always write an internal copy for reliable FileProvider sharing (AxManager / ZArchiver)
        val internalDir = File(context.filesDir, "modules").apply { mkdirs() }
        val internalFile = File(internalDir, zipFileName)
        FileOutputStream(internalFile).use { fos ->
          fos.write(zipBytes)
          fos.flush()
        }
        val shareUri =
          runCatching {
              FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                internalFile,
              )
            }
            .getOrNull()

        // 2. Write to public Downloads folder using MediaStore (Android 10+) or legacy Downloads dir
        val displayPath = saveToPublicDownloads(zipFileName, zipBytes)

        ZipBuildOutput(
          fileName = zipFileName,
          downloadsDisplayPath = displayPath,
          shareUriString = shareUri?.toString(),
        )
      }
    }

  private fun saveToPublicDownloads(fileName: String, bytes: ByteArray): String {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      val resolver = context.contentResolver
      val collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)

      // Remove existing entry with same name created by this app if present
      runCatching {
        resolver.delete(
          collection,
          "${MediaStore.Downloads.DISPLAY_NAME} = ?",
          arrayOf(fileName),
        )
      }

      val values =
        ContentValues().apply {
          put(MediaStore.Downloads.DISPLAY_NAME, fileName)
          put(MediaStore.Downloads.MIME_TYPE, "application/zip")
          put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
          put(MediaStore.Downloads.IS_PENDING, 1)
        }

      val itemUri = resolver.insert(collection, values)
      if (itemUri != null) {
        resolver.openOutputStream(itemUri)?.use { os ->
          os.write(bytes)
          os.flush()
        }
        val completeValues = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
        resolver.update(itemUri, completeValues, null, null)
        return "Downloads/$fileName"
      }
    }

    // Fallback for Android 8.0-9 or if MediaStore insert returned null
    val publicSaved =
      runCatching {
        @Suppress("DEPRECATION")
        val downloadsDir =
          Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        if (!downloadsDir.exists()) downloadsDir.mkdirs()
        val outFile = File(downloadsDir, fileName)
        FileOutputStream(outFile).use { it.write(bytes) }
        "Downloads/$fileName"
      }

    return publicSaved.getOrElse {
      val appDownloads =
        context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
      if (!appDownloads.exists()) appDownloads.mkdirs()
      val fallbackFile = File(appDownloads, fileName)
      FileOutputStream(fallbackFile).use { it.write(bytes) }
      "Downloads/$fileName"
    }
  }

  private fun createModuleZipBytes(module: GeneratedModule): ByteArray {
    val baos = ByteArrayOutputStream()
    val bannerPngBytes = generateModuleBannerPng(module)
    ZipOutputStream(baos).use { zos ->
      writeEntry(zos, "module.prop", module.toModuleProp())
      if (bannerPngBytes != null) {
        writeBinaryEntry(zos, "banner.png", bannerPngBytes)
      }
      writeEntry(zos, "service.sh", module.serviceSh)
      writeEntry(zos, "action.sh", module.actionSh)
      writeEntry(zos, "system.prop", module.systemProp)
      writeEntry(zos, "customize.sh", buildCustomizeScript(module))
      writeEntry(zos, "uninstall.sh", module.uninstallSh)
      writeEntry(zos, "META-INF/com/google/android/update-binary", UPDATE_BINARY_SCRIPT)
      writeEntry(zos, "META-INF/com/google/android/updater-script", "#MAGISK\n")
    }
    return baos.toByteArray()
  }

  private fun generateModuleBannerPng(module: GeneratedModule): ByteArray? {
    return runCatching {
        val width = 1080
        val height = 480
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        try {
          val canvas = Canvas(bitmap)

          // 1. Degradê Preto OLED (#050505) para Verde Escuro (#0A1F12)
          val bgPaint =
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
              shader =
                LinearGradient(
                  0f,
                  0f,
                  width.toFloat(),
                  height.toFloat(),
                  Color.parseColor("#050505"),
                  Color.parseColor("#0A1F12"),
                  Shader.TileMode.CLAMP,
                )
            }
          canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

          // 2. Grade tecnológica sutil de fundo
          val gridPaint =
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
              color = Color.argb(24, 0, 255, 102)
              strokeWidth = 1.5f
            }
          var x = 60f
          while (x < width) {
            canvas.drawLine(x, 0f, x, height.toFloat(), gridPaint)
            x += 60f
          }
          var y = 60f
          while (y < height) {
            canvas.drawLine(0f, y, width.toFloat(), y, gridPaint)
            y += 60f
          }

          // Linhas diagonais tech à direita
          val diagPaint =
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
              color = Color.argb(42, 0, 255, 102)
              strokeWidth = 3f
            }
          canvas.drawLine(width - 260f, 0f, width - 40f, height.toFloat(), diagPaint)
          canvas.drawLine(width - 200f, 0f, width + 20f, height.toFloat(), diagPaint)

          // 3. Borda externa sutil e cantos tecnológicos em Verde Neon (#00FF66)
          val framePaint =
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
              color = Color.argb(90, 0, 255, 102)
              style = Paint.Style.STROKE
              strokeWidth = 2.5f
            }
          canvas.drawRect(24f, 24f, width - 24f, height - 24f, framePaint)

          val cornerPaint =
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
              color = Color.parseColor("#00FF66")
              style = Paint.Style.STROKE
              strokeWidth = 6f
              strokeCap = Paint.Cap.SQUARE
            }
          val cLen = 46f
          val pad = 24f
          // Top-left corner
          canvas.drawLine(pad, pad, pad + cLen, pad, cornerPaint)
          canvas.drawLine(pad, pad, pad, pad + cLen, cornerPaint)
          // Top-right corner
          canvas.drawLine(width - pad - cLen, pad, width - pad, pad, cornerPaint)
          canvas.drawLine(width - pad, pad, width - pad, pad + cLen, cornerPaint)
          // Bottom-left corner
          canvas.drawLine(pad, height - pad, pad + cLen, height - pad, cornerPaint)
          canvas.drawLine(pad, height - pad - cLen, pad, height - pad, cornerPaint)
          // Bottom-right corner
          canvas.drawLine(width - pad - cLen, height - pad, width - pad, height - pad, cornerPaint)
          canvas.drawLine(width - pad, height - pad - cLen, width - pad, height - pad, cornerPaint)

          // Barra lateral esquerda Neon
          val barPaint =
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
              color = Color.parseColor("#00FF66")
            }
          canvas.drawRoundRect(RectF(62f, 68f, 72f, height - 68f), 5f, 5f, barPaint)

          // 4. Badge tecnológica "AXMANAGER PLUGIN • SHIZUKU UID 2000"
          val badgeText = "AXMANAGER PLUGIN • SHIZUKU UID 2000"
          val badgeTextPaint =
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
              color = Color.parseColor("#00FF66")
              textSize = 23f
              typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
              letterSpacing = 0.06f
            }
          val badgeTextWidth = badgeTextPaint.measureText(badgeText)
          val badgeRect = RectF(100f, 68f, 100f + badgeTextWidth + 40f, 118f)
          val badgeFillPaint =
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
              color = Color.argb(38, 0, 255, 102)
            }
          val badgeStrokePaint =
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
              color = Color.parseColor("#00FF66")
              style = Paint.Style.STROKE
              strokeWidth = 2f
            }
          canvas.drawRoundRect(badgeRect, 10f, 10f, badgeFillPaint)
          canvas.drawRoundRect(badgeRect, 10f, 10f, badgeStrokePaint)
          canvas.drawText(badgeText, 120f, 101f, badgeTextPaint)

          // 5. Título do módulo em destaque em Branco Puro no centro/esquerda
          val titlePaint =
            TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
              color = Color.WHITE
              textSize = 56f
              typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
          val maxTitleWidth = width - 170
          val titleLayout =
            StaticLayout.Builder.obtain(
                module.name,
                0,
                module.name.length,
                titlePaint,
                maxTitleWidth,
              )
              .setAlignment(Layout.Alignment.ALIGN_NORMAL)
              .setMaxLines(2)
              .setLineSpacing(6f, 1f)
              .build()
          canvas.save()
          canvas.translate(100f, 154f)
          titleLayout.draw(canvas)
          canvas.restore()

          // Subtítulo com ID e descrição resumida
          val subtitleText = module.description.replace('\n', ' ').trim()
          val descPaint =
            TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
              color = Color.parseColor("#A7BDB1")
              textSize = 24f
              typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            }
          val descY = 166f + titleLayout.height + 14f
          if (descY < height - 100f) {
            val descLayout =
              StaticLayout.Builder.obtain(
                  subtitleText,
                  0,
                  subtitleText.length,
                  descPaint,
                  maxTitleWidth,
                )
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setMaxLines(2)
                .setLineSpacing(4f, 1f)
                .build()
            canvas.save()
            canvas.translate(100f, descY)
            descLayout.draw(canvas)
            canvas.restore()
          }

          // 6. Assinatura "CRIADO POR RAYLAN" e versão no rodapé
          val idMetaPaint =
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
              color = Color.parseColor("#7D9487")
              textSize = 21f
              typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
            }
          canvas.drawText("${module.id}  •  ${module.version}", 100f, height - 62f, idMetaPaint)

          val signatureText = "CRIADO POR RAYLAN"
          val signaturePaint =
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
              color = Color.parseColor("#00FF66")
              textSize = 24f
              typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
              letterSpacing = 0.08f
            }
          val sigWidth = signaturePaint.measureText(signatureText)
          canvas.drawText(signatureText, width - 64f - sigWidth, height - 62f, signaturePaint)

          val pngStream = ByteArrayOutputStream()
          bitmap.compress(Bitmap.CompressFormat.PNG, 100, pngStream)
          pngStream.toByteArray()
        } finally {
          bitmap.recycle()
        }
      }
      .getOrNull()
  }

  private fun writeEntry(zos: ZipOutputStream, path: String, content: String) {
    val normalizedLf = content.replace("\r\n", "\n").replace("\r", "\n")
    val entry = ZipEntry(path)
    zos.putNextEntry(entry)
    zos.write(normalizedLf.toByteArray(StandardCharsets.UTF_8))
    zos.closeEntry()
  }

  private fun writeBinaryEntry(zos: ZipOutputStream, path: String, bytes: ByteArray) {
    val entry = ZipEntry(path)
    zos.putNextEntry(entry)
    zos.write(bytes)
    zos.closeEntry()
  }

  private fun sanitizeFileName(name: String): String {
    val cleaned =
      name
        .trim()
        .replace(Regex("[^A-Za-z0-9._-]+"), "_")
        .trim('_')
    return if (cleaned.isBlank()) "Raylan_Module_AI" else cleaned.take(54)
  }

  private fun buildCustomizeScript(module: GeneratedModule): String =
    """
    #!/system/bin/sh
    SKIPUNZIP=0

    ui_print "*****************************************"
    ui_print "  RAYLAN MODULE AI - INSTALADOR OFICIAL  "
    ui_print "*****************************************"
    ui_print "  Módulo: ${module.name}"
    ui_print "  ID: ${module.id}"
    ui_print "  Autor: ${module.author}"
    ui_print "*****************************************"
    ui_print "- Extraindo arquivos e ajustando permissões..."

    set_perm_recursive "${'$'}MODPATH" 0 0 0755 0644
    [ -f "${'$'}MODPATH/service.sh" ] && set_perm "${'$'}MODPATH/service.sh" 0 0 0755
    [ -f "${'$'}MODPATH/action.sh" ] && set_perm "${'$'}MODPATH/action.sh" 0 0 0755
    [ -f "${'$'}MODPATH/uninstall.sh" ] && set_perm "${'$'}MODPATH/uninstall.sh" 0 0 0755

    ui_print "- Instalação concluída com sucesso!"
    """.trimIndent() + "\n"

  companion object {
    private val UPDATE_BINARY_SCRIPT =
      """
      #!/sbin/sh
      #################
      # Initialization
      #################
      umask 022
      OUTFD=${'$'}2
      ZIPFILE=${'$'}3

      ui_print() {
        echo "ui_print ${'$'}1" >> /proc/self/fd/${'$'}OUTFD
        echo "ui_print" >> /proc/self/fd/${'$'}OUTFD
      }

      require_new_magisk() {
        ui_print "*******************************"
        ui_print " Please install Magisk v20.4+! "
        ui_print "*******************************"
        exit 1
      }

      #########################
      # Load util_functions.sh
      #########################
      mount /data 2>/dev/null
      [ -f /data/adb/magisk/util_functions.sh ] || require_new_magisk
      . /data/adb/magisk/util_functions.sh
      [ ${'$'}MAGISK_VER_CODE -lt 20400 ] && require_new_magisk

      install_module
      exit 0
      """.trimIndent() + "\n"
  }
}

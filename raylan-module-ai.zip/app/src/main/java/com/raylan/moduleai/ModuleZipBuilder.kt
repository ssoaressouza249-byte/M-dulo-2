package com.raylan.moduleai

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.charset.StandardCharsets
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class ZipBuildOutput(
  val fileName: String,
  val downloadsDisplayPath: String,
  val shareUriString: String?,
)

class ModuleZipBuilder(private val context: Context) {

  suspend fun buildAndSaveToDownloads(module: GeneratedModule): Result<ZipBuildOutput> =
    withContext(Dispatchers.IO) {
      runCatching {
        val safeBaseName = sanitizeFileName(module.name)
        val zipFileName = "${safeBaseName}.zip"
        val zipBytes = createModuleZipBytes(module)

        // 1. Always write an internal copy for reliable FileProvider sharing (AxManager / ZArchiver)
        val internalDir = File(context.filesDir, "modules").apply { mkdirs() }
        val internalFile = File(internalDir, zipFileName)
        FileOutputStream(internalFile).use { fos ->
          fos.write(zipBytes)
          fos.flush()
        }
        val shareUri =
          runCatching {
              FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                internalFile,
              )
            }
            .getOrNull()

        // 2. Write to public Downloads folder using MediaStore (Android 10+) or legacy Downloads dir
        val displayPath = saveToPublicDownloads(zipFileName, zipBytes)

        ZipBuildOutput(
          fileName = zipFileName,
          downloadsDisplayPath = displayPath,
          shareUriString = shareUri?.toString(),
        )
      }
    }

  private fun saveToPublicDownloads(fileName: String, bytes: ByteArray): String {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      val resolver = context.contentResolver
      val collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)

      // Remove existing entry with same name created by this app if present
      runCatching {
        resolver.delete(
          collection,
          "${MediaStore.Downloads.DISPLAY_NAME} = ?",
          arrayOf(fileName),
        )
      }

      val values =
        ContentValues().apply {
          put(MediaStore.Downloads.DISPLAY_NAME, fileName)
          put(MediaStore.Downloads.MIME_TYPE, "application/zip")
          put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
          put(MediaStore.Downloads.IS_PENDING, 1)
        }

      val itemUri = resolver.insert(collection, values)
      if (itemUri != null) {
        resolver.openOutputStream(itemUri)?.use { os ->
          os.write(bytes)
          os.flush()
        }
        val completeValues = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
        resolver.update(itemUri, completeValues, null, null)
        return "Downloads/$fileName"
      }
    }

    // Fallback for Android 8.0-9 or if MediaStore insert returned null
    val publicSaved =
      runCatching {
        @Suppress("DEPRECATION")
        val downloadsDir =
          Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        if (!downloadsDir.exists()) downloadsDir.mkdirs()
        val outFile = File(downloadsDir, fileName)
        FileOutputStream(outFile).use { it.write(bytes) }
        "Downloads/$fileName"
      }

    return publicSaved.getOrElse {
      val appDownloads =
        context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
      if (!appDownloads.exists()) appDownloads.mkdirs()
      val fallbackFile = File(appDownloads, fileName)
      FileOutputStream(fallbackFile).use { it.write(bytes) }
      "Downloads/$fileName"
    }
  }

  private fun createModuleZipBytes(module: GeneratedModule): ByteArray {
    val baos = ByteArrayOutputStream()
    ZipOutputStream(baos).use { zos ->
      writeEntry(zos, "module.prop", module.toModuleProp())
      writeEntry(zos, "service.sh", module.serviceSh)
      writeEntry(zos, "action.sh", module.actionSh)
      writeEntry(zos, "system.prop", module.systemProp)
      writeEntry(zos, "customize.sh", buildCustomizeScript(module))
      writeEntry(zos, "uninstall.sh", module.uninstallSh)
      writeEntry(zos, "META-INF/com/google/android/update-binary", UPDATE_BINARY_SCRIPT)
      writeEntry(zos, "META-INF/com/google/android/updater-script", "#MAGISK\n")
    }
    return baos.toByteArray()
  }

  private fun writeEntry(zos: ZipOutputStream, path: String, content: String) {
    val normalizedLf = content.replace("\r\n", "\n").replace("\r", "\n")
    val entry = ZipEntry(path)
    zos.putNextEntry(entry)
    zos.write(normalizedLf.toByteArray(StandardCharsets.UTF_8))
    zos.closeEntry()
  }

  private fun sanitizeFileName(name: String): String {
    val cleaned =
      name
        .trim()
        .replace(Regex("[^A-Za-z0-9._-]+"), "_")
        .trim('_')
    return if (cleaned.isBlank()) "Raylan_Module_AI" else cleaned.take(54)
  }

  private fun buildCustomizeScript(module: GeneratedModule): String =
    """
    #!/system/bin/sh
    SKIPUNZIP=0

    ui_print "*****************************************"
    ui_print "  RAYLAN MODULE AI - INSTALADOR OFICIAL  "
    ui_print "*****************************************"
    ui_print "  Módulo: ${module.name}"
    ui_print "  ID: ${module.id}"
    ui_print "  Autor: ${module.author}"
    ui_print "*****************************************"
    ui_print "- Extraindo arquivos e ajustando permissões..."

    set_perm_recursive "${'$'}MODPATH" 0 0 0755 0644
    [ -f "${'$'}MODPATH/service.sh" ] && set_perm "${'$'}MODPATH/service.sh" 0 0 0755
    [ -f "${'$'}MODPATH/action.sh" ] && set_perm "${'$'}MODPATH/action.sh" 0 0 0755
    [ -f "${'$'}MODPATH/uninstall.sh" ] && set_perm "${'$'}MODPATH/uninstall.sh" 0 0 0755

    ui_print "- Instalação concluída com sucesso!"
    """.trimIndent() + "\n"

  companion object {
    private val UPDATE_BINARY_SCRIPT =
      """
      #!/sbin/sh
      #################
      # Initialization
      #################
      umask 022
      OUTFD=${'$'}2
      ZIPFILE=${'$'}3

      ui_print() {
        echo "ui_print ${'$'}1" >> /proc/self/fd/${'$'}OUTFD
        echo "ui_print" >> /proc/self/fd/${'$'}OUTFD
      }

      require_new_magisk() {
        ui_print "*******************************"
        ui_print " Please install Magisk v20.4+! "
        ui_print "*******************************"
        exit 1
      }

      #########################
      # Load util_functions.sh
      #########################
      mount /data 2>/dev/null
      [ -f /data/adb/magisk/util_functions.sh ] || require_new_magisk
      . /data/adb/magisk/util_functions.sh
      [ ${'$'}MAGISK_VER_CODE -lt 20400 ] && require_new_magisk

      install_module
      exit 0
      """.trimIndent() + "\n"
  }
}
